"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Menu, Search, X, Moon, Sun, Facebook, Youtube, Twitter, Radio } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { categories } from "@/lib/mock-data"
import { useLanguage, getCategoryName } from "@/lib/language-context"
import { getSiteSettings, type SiteSettings } from "@/components/footer"

export function Header() {
  const router = useRouter()
  const [currentTime, setCurrentTime] = useState<string>("")
  const [currentDate, setCurrentDate] = useState<string>("")
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const { language, setLanguage } = useLanguage()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [settings, setSettings] = useState<SiteSettings | null>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setSettings(getSiteSettings())
    const handler = () => setSettings(getSiteSettings())
    window.addEventListener("tinph_settings_updated", handler)
    return () => window.removeEventListener("tinph_settings_updated", handler)
  }, [])

  useEffect(() => {
    setMounted(true)
    const update = () => {
      const now = new Date()
      setCurrentTime(now.toLocaleTimeString("en-PH", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true }))
      setCurrentDate(now.toLocaleDateString("en-PH", { weekday: "long", year: "numeric", month: "long", day: "numeric" }))
    }
    update()
    const iv = setInterval(update, 1000)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }, [isSearchOpen])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
      setIsSearchOpen(false)
    }
  }

  const handleSearchKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch(e as any)
    }
    if (e.key === "Escape") {
      setIsSearchOpen(false)
      setSearchQuery("")
    }
  }

  const handleDesktopSearch = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
      setSearchQuery("")
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full">

      {/* ── Redesigned top bar ── */}
      <div className="bg-[#0D1B2A] border-b border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-9">

            {/* Left: Live badge + date/time */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 bg-[#CE1126] px-2 py-0.5 rounded text-white text-[10px] font-bold tracking-widest uppercase">
                <Radio className="h-2.5 w-2.5 animate-pulse" />
                Live
              </div>
              <span className="text-white/50 text-[11px] hidden sm:inline" suppressHydrationWarning>
                {currentDate}
              </span>
              <span className="text-white/80 font-mono text-[11px] font-bold tracking-widest tabular-nums" suppressHydrationWarning>
                {currentTime}
              </span>
            </div>

            {/* Right: socials + lang + theme */}
            <div className="flex items-center gap-0.5">
              {settings?.facebook && (
                <a href={settings.facebook} target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 flex items-center justify-center text-white/40 hover:text-[#FCD116] transition-colors">
                  <Facebook className="h-3.5 w-3.5" />
                </a>
              )}
              {settings?.twitter && (
                <a href={settings.twitter} target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 flex items-center justify-center text-white/40 hover:text-[#FCD116] transition-colors">
                  <Twitter className="h-3.5 w-3.5" />
                </a>
              )}
              {settings?.youtube && (
                <a href={settings.youtube} target="_blank" rel="noopener noreferrer"
                  className="w-7 h-7 flex items-center justify-center text-white/40 hover:text-[#FCD116] transition-colors">
                  <Youtube className="h-3.5 w-3.5" />
                </a>
              )}
              <div className="w-px h-3 bg-white/20 mx-1" />
              <button suppressHydrationWarning onClick={() => setLanguage(language === "EN" ? "FIL" : "EN")}
                className="px-2 h-7 text-white/50 hover:text-[#FCD116] text-[11px] font-semibold tracking-wider transition-colors">
                {language}
              </button>
              {mounted && (
                <button suppressHydrationWarning onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="w-7 h-7 flex items-center justify-center text-white/40 hover:text-[#FCD116] transition-colors">
                  {theme === "dark" ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Main white header bar ── */}
      <div className="bg-white dark:bg-[#0f172a] border-b-2 border-[#002D72] shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-[70px]">

            <div className="hidden md:flex flex-1" />

            <Link href="/" className="flex items-center shrink-0 group">
              <Image
                src="/tinph-logo.png"
                alt="The Insider News Philippines"
                width={180}
                height={72}
                className="object-contain h-[56px] w-auto drop-shadow-sm group-hover:opacity-90 transition-opacity"
                priority
              />
            </Link>

            {/* RIGHT: search + subscribe */}
            <div className="hidden md:flex items-center gap-3 shrink-0 flex-1 justify-end">
              <div className="relative">
                <input
                  suppressHydrationWarning
                  type="text"
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={handleDesktopSearch}
                  className="w-52 px-4 py-1.5 pl-9 rounded-none border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-white/5 text-gray-800 dark:text-white text-sm placeholder:text-gray-400 focus:outline-none focus:border-[#002D72] focus:ring-0 transition-colors"
                />
                <button
                  onClick={() => {
                    if (searchQuery.trim()) router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
                  }}
                  className="absolute left-0 top-0 h-full px-2.5 flex items-center text-gray-400 hover:text-[#002D72] transition-colors"
                >
                  <Search className="h-3.5 w-3.5" />
                </button>
              </div>
              <Link href="/newsletter"
                className="bg-[#002D72] hover:bg-[#001a4a] text-white text-xs font-bold px-4 py-2 tracking-wider uppercase transition-colors whitespace-nowrap rounded-none">
                Subscribe
              </Link>
            </div>

            {/* Mobile controls */}
            <div className="flex items-center gap-1 md:hidden">
              <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(v => !v)}
                className="text-gray-600 dark:text-gray-300 h-8 w-8">
                {isSearchOpen ? <X className="h-4 w-4" /> : <Search className="h-4 w-4" />}
              </Button>
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-gray-600 dark:text-gray-300 h-8 w-8">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[280px] bg-white dark:bg-[#0f172a] border-gray-200 dark:border-[#002D72]">
                  <div className="flex flex-col gap-1 mt-8">
                    <Link href="/" className="mb-5 flex justify-center">
                      <Image src="/tinph-logo.png" alt="The Insider News Philippines" width={150} height={60} className="object-contain" />
                    </Link>
                    {categories.map((cat) => (
                      <Link key={cat.slug} href={`/category/${cat.slug}`}
                        className="text-gray-700 dark:text-gray-300 hover:text-[#CE1126] py-2 px-3 border-b border-gray-100 dark:border-white/10 text-sm transition-colors font-medium">
                        {getCategoryName(cat.slug, language)}
                      </Link>
                    ))}
                    <Link href="/admin" className="text-[#CE1126] hover:text-[#002D72] py-2 px-3 mt-4 text-sm font-bold">Admin Panel</Link>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Mobile search */}
          {isSearchOpen && (
            <div className="pb-3 md:hidden">
              <form onSubmit={handleSearch} className="relative">
                <input
                  ref={searchInputRef}
                  suppressHydrationWarning
                  type="text"
                  placeholder="Search news... (press Enter)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={handleSearchKeyDown}
                  className="w-full px-4 py-2 pr-10 border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-white/5 text-gray-800 dark:text-white text-sm placeholder:text-gray-400 focus:outline-none focus:border-[#002D72] rounded-none"
                />
                <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#002D72]">
                  <Search className="h-4 w-4" />
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* ── Navigation ── */}
      <nav className="bg-[#002D72] hidden md:block">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center">
            {categories.map((cat) => (
              <Link key={cat.slug} href={`/category/${cat.slug}`}
                className="px-4 py-2.5 text-[13px] font-semibold text-white/80 hover:text-white hover:bg-white/10 transition-colors border-b-2 border-transparent hover:border-[#FCD116] tracking-wide uppercase">
                {getCategoryName(cat.slug, language)}
              </Link>
            ))}
          </div>
        </div>
      </nav>

    </header>
  )
}
