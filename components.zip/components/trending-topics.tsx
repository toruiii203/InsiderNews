"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { TrendingUp, Hash, Zap } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const allTopics = [
  { tag: "Election2028", count: 15420, category: "Politics" },
  { tag: "PesoStrength", count: 12350, category: "Business" },
  { tag: "GilasPilipinas", count: 9870, category: "Sports" },
  { tag: "MNLTraffic", count: 8540, category: "Metro" },
  { tag: "PhilippineTourism", count: 7230, category: "Travel" },
  { tag: "TechPH", count: 6890, category: "Technology" },
  { tag: "OFWNews", count: 5670, category: "World" },
  { tag: "HealthPH", count: 4980, category: "Lifestyle" },
  { tag: "WestPhilippineSea", count: 18900, category: "Nation" },
  { tag: "PalawanTourism", count: 11200, category: "Travel" },
  { tag: "PesoWatch", count: 9100, category: "Business" },
  { tag: "TyphoonAlert", count: 8300, category: "Nation" },
  { tag: "BangsamoroNews", count: 6100, category: "Regions" },
  { tag: "CebuBusiness", count: 5500, category: "Business" },
  { tag: "MNLFlood", count: 4400, category: "Metro" },
]

function simulateCounts(topics: typeof allTopics) {
  return topics.map(t => ({
    ...t,
    count: Math.max(1000, t.count + Math.round((Math.random() - 0.48) * 200))
  }))
}

export function TrendingTopics() {
  const [topics, setTopics] = useState(allTopics.slice(0, 8))
  const [rotateIndex, setRotateIndex] = useState(0)
  const [flash, setFlash] = useState<number | null>(null)

  // Every 12 seconds: rotate one random topic in
  useEffect(() => {
    const iv = setInterval(() => {
      setTopics(prev => {
        const updated = simulateCounts(prev)
        // Swap one random topic for a different one from allTopics
        const swapIdx = Math.floor(Math.random() * 8)
        const notInCurrent = allTopics.filter(t => !prev.find(p => p.tag === t.tag))
        if (notInCurrent.length === 0) return updated
        const newTopic = notInCurrent[Math.floor(Math.random() * notInCurrent.length)]
        const next = [...updated]
        next[swapIdx] = newTopic
        // Re-sort by count descending
        next.sort((a, b) => b.count - a.count)
        setFlash(swapIdx)
        setTimeout(() => setFlash(null), 1500)
        return next
      })
      setRotateIndex(i => i + 1)
    }, 12000)
    return () => clearInterval(iv)
  }, [])

  // Simulate small count fluctuations every 4 seconds
  useEffect(() => {
    const iv = setInterval(() => {
      setTopics(prev => simulateCounts(prev))
    }, 4000)
    return () => clearInterval(iv)
  }, [])

  return (
    <section className="py-5 border-y border-border bg-card">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-[#CE1126]" />
            <h2 className="text-xl font-serif font-bold text-foreground">
              Trending Topics
            </h2>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>Updating live</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          {topics.map((topic, index) => (
            <Link 
              key={`${topic.tag}-${rotateIndex}`}
              href={`/search?q=${topic.tag}`}
              className="group"
            >
              <Badge 
                variant={index < 3 ? "default" : "outline"}
                className={`
                  px-4 py-2 text-sm font-medium transition-all duration-500 cursor-pointer
                  ${flash === index ? "scale-105 ring-2 ring-[#FCD116]" : ""}
                  ${index < 3 
                    ? "bg-gradient-to-r from-[#CE1126] to-[#CE1126]/80 hover:from-[#CE1126]/90 hover:to-[#CE1126]/70 text-white border-0" 
                    : "hover:bg-[#002D72] hover:text-white hover:border-[#002D72]"
                  }
                `}
              >
                <Hash className="h-3 w-3 mr-1 inline" />
                {topic.tag}
                <span className="ml-2 text-xs opacity-70">
                  {(topic.count / 1000).toFixed(1)}k
                </span>
              </Badge>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
